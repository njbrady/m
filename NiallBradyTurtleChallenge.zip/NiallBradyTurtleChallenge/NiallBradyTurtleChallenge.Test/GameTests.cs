﻿using System.Collections.Generic;
using NiallBradyTurtleChallenge;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NiallBradyTurtleChallengeTests
{
    [TestClass]
    public class GameTests
    {
        private Game _game;

        [TestInitialize]
        public void TestInitialize()
        {
            _game = new Game(new Board(new BoardSettings()
            {
                TurtleInitialFacing = TurtleFacing.North,
                Tiles = new[,]{
                    { TileType.Plain,   TileType.Plain, TileType.Plain, TileType.Plain, TileType.Plain },
                    { TileType.Start,   TileType.Mine,  TileType.Plain, TileType.Mine,  TileType.Plain },
                    { TileType.Plain,   TileType.Plain, TileType.Plain, TileType.Plain, TileType.Exit },
                    { TileType.Plain,   TileType.Plain, TileType.Plain, TileType.Mine,  TileType.Plain }
                }
            }));
        }

        [TestMethod]
        public void Game_Tick_ShouldMineHit()
        {
            var actions = new Stack<TurtleAction>(new[] {
                TurtleAction.Move,      // last move
                TurtleAction.Rotate,    // first move
            });
            Assert.AreEqual(_game.Tick(actions), Outcome.MineHit);
        }

        [TestMethod]
        public void Game_Tick_ShouldSuccess()
        {
            var actions = new Stack<TurtleAction>(new[] {
                TurtleAction.Move,      // last move
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,      // first move
            });
            Assert.AreEqual(_game.Tick(actions), Outcome.Success);
        }

        [TestMethod]
        public void Game_Tick_ShouldStillInDanger()
        {
            var actions = new Stack<TurtleAction>(new[] {  
                TurtleAction.Move,      // last move
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,      // first move    
            });
            Assert.AreEqual(_game.Tick(actions), Outcome.StillInDanger);
        }

        [TestMethod]
        public void Game_Tick_ShouldClampToBordersSuccess()
        {
            var actions = new Stack<TurtleAction>(new[] {
                TurtleAction.Move,      // last move
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Rotate,
                TurtleAction.Move,
                TurtleAction.Move,
                TurtleAction.Move,      // first move   
            });
            Assert.AreEqual(_game.Tick(actions), Outcome.Success);
        }
    }
}
