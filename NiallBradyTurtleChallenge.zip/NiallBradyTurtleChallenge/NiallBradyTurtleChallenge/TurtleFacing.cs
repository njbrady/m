﻿
namespace NiallBradyTurtleChallenge
{
    public enum TurtleFacing
    {
        North,
        East,
        South,
        West
    }
}
