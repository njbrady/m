﻿
namespace NiallBradyTurtleChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            new Application(args[0], args[1]).Run();
        }
    }
}
