﻿
namespace NiallBradyTurtleChallenge
{
    public enum TileType
    {
        Mine,
        Exit,
        Start,
        Plain
    }
}
