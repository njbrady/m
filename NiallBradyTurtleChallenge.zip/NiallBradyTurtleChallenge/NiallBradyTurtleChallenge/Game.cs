﻿using System.Collections.Generic;

namespace NiallBradyTurtleChallenge
{
    public class Game
    {
        private Board _board;

        public Game(Board board)
        {
            _board = board;
        }

        public Outcome Tick(Stack<TurtleAction> turtleActions)
        {
            var turtle = new Turtle(_board.TurtleStartPosition, _board.TurtleInitialFacing, turtleActions);
            while (turtle.Step(_board))
            {
                switch (_board.TileTypeAt(turtle.Position))
                {
                    case TileType.Mine:
                        return Outcome.MineHit;

                    case TileType.Exit:
                        return Outcome.Success;
                }
            };
            return Outcome.StillInDanger;
        }
    }
}
