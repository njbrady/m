﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace NiallBradyTurtleChallenge
{
    class Application
    {
        private Game _game;
        private Stack<Stack<TurtleAction>> _turtleSequences;

        public Application(string boardSettingsPath, string turtleSequencesPath)
        {
            BoardSettings boardSettings;
            using (var reader = File.OpenText(boardSettingsPath))
            {
                boardSettings = JsonConvert.DeserializeObject<BoardSettings>(reader.ReadToEnd());
            }

            _game = new Game(new Board(boardSettings));

            using (var reader = File.OpenText(turtleSequencesPath))
            {
                _turtleSequences = JsonConvert.DeserializeObject<Stack<Stack<TurtleAction>>>(reader.ReadToEnd());
            }
        }

        public void Run()
        {
            while (_turtleSequences.Count != 0)
            {
                int sequenceNumber = _turtleSequences.Count;
                switch (_game.Tick(_turtleSequences.Pop()))
                {
                    case Outcome.MineHit:
                        Message(sequenceNumber, "Mine hit");
                        break;

                    case Outcome.Success:
                        Message(sequenceNumber, "Success");
                        break;

                    case Outcome.StillInDanger:
                        Message(sequenceNumber, "Still in danger");
                        break;
                }
            }
        }

        private void Message(int sequenceNumber, String message)
        {
            Console.WriteLine($"Sequence {sequenceNumber}: {message}!");
        }
    }
}
