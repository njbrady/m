﻿
namespace NiallBradyTurtleChallenge
{
    public class BoardSettings
    {
        public TurtleFacing TurtleInitialFacing { get; set; }
        public TileType[,] Tiles { get; set; }
    }
}
