﻿using System;
using System.Linq;
using System.Drawing;

namespace NiallBradyTurtleChallenge
{
    public class Board
    {
        private TileType[] _tiles;
        private Size _shape;
        private Point _turtleStartPosition;
        private TurtleFacing _turtleInitialFacing;

        public Board(BoardSettings boardSettings)
        {
            _shape = new Size(boardSettings.Tiles.GetLength(1), boardSettings.Tiles.GetLength(0));
            _turtleInitialFacing = boardSettings.TurtleInitialFacing;
            _tiles = boardSettings.Tiles.Cast<TileType>().ToArray();


            for (int i = 0; i < _tiles.Length; i++)
            {
                if (_tiles[i] == TileType.Start)
                {
                    _turtleStartPosition = CalculatePosition(i);
                    break;
                }
            }
        }

        public TileType TileTypeAt(Point position)
        {
            return _tiles[CalculateIndex(position)];
        }

        public Point ClampPosition(Point position)
        {
            return new Point(Math.Min(Math.Max(position.X, 0), _shape.Width - 1), Math.Min(Math.Max(position.Y, 0), _shape.Height - 1));
        }

        public Point TurtleStartPosition { get { return _turtleStartPosition; } }
        public TurtleFacing TurtleInitialFacing { get { return _turtleInitialFacing; } }

        private Point CalculatePosition(int index)
        {
            return new Point(index % _shape.Width, index / _shape.Width);
        }

        private int CalculateIndex(Point position)
        {
            return position.Y * _shape.Width + position.X;
        }
    }
}
