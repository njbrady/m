﻿
namespace NiallBradyTurtleChallenge
{
    public enum TurtleAction
    {
        Rotate,
        Move
    }
}
