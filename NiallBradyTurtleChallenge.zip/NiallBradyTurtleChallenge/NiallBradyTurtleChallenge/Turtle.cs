﻿using System.Collections.Generic;
using System.Drawing;

namespace NiallBradyTurtleChallenge
{
    class Turtle
    {
        private static Dictionary<TurtleFacing, TurtleFacing> RotateMap = new Dictionary<TurtleFacing, TurtleFacing>()
        {
            [TurtleFacing.North] = TurtleFacing.West,
            [TurtleFacing.West] = TurtleFacing.South,
            [TurtleFacing.South] = TurtleFacing.East,
            [TurtleFacing.East] = TurtleFacing.North,
        };

        private Stack<TurtleAction> _actions;
        private TurtleFacing _facing;
        private Point _position;

        public Turtle(Point position, TurtleFacing facing, Stack<TurtleAction> actions)
        {
            _position = position;
            _facing = facing;
            _actions = actions;
        }

        public Point Position { get { return _position; } }

        public bool Step(Board board)
        {
            if (_actions.Count == 0)
                return false;

            switch (_actions.Pop())
            {
                case TurtleAction.Rotate:
                    _facing = RotateMap[_facing];
                    break;

                case TurtleAction.Move:
                    Point newPosition;
                    if (_facing == TurtleFacing.North)
                        newPosition = new Point(Position.X, Position.Y - 1);
                    else if (_facing == TurtleFacing.West)
                        newPosition = new Point(Position.X + 1, Position.Y);
                    else if (_facing == TurtleFacing.South)
                        newPosition = new Point(Position.X, Position.Y + 1);
                    else
                        newPosition = new Point(Position.X - 1, Position.Y);

                    _position = board.ClampPosition(newPosition);
                    break;
            }
            return true;
        }
    }
}
